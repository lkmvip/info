function ownfkaj(){
    var el_toolbar = document.getElementById('js_toobar3');
    var el_likeNum = el_toolbar.querySelector('#likeNum3'),
    el_readNum = el_toolbar.querySelector('#readNum3');
    var readNum = parseInt(el_readNum.innerHTML);
    var likeNum = parseInt(el_likeNum.innerHTML);
    var re = {"result": "eccute😄🌑😄🌑😄","read_num":readNum, "like_num":likeNum};
    return JSON.stringify(re);
}

ownfkaj();





