function classFunction() {
    'use strict';
    function s(s, a) {
        return s.classList ? s.classList.contains(a) : s.className.match(new RegExp('(\\s|^)' + a + '(\\s|$)'));
    }
    function a(s, a) {
        s.classList ? s.classList.add(a) : this.hasClass(s, a) || (s.className += ' ' + a);
    }
    function e(a, e) {
        if (a.classList)
            a.classList.remove(e);
        else if (s(a, e)) {
            var c = new RegExp('(\\s|^)' + e + '(\\s|$)');
            a.className = a.className.replace(c, ' ');
        }
    }
    function c(c, l) {
        s(c, l) ? e(c, l) : a(c, l);
    }
    return {
        hasClass: s,
        addClass: a,
        removeClass: e,
        toggleClass: c
    };
};

function urlFunction() {
    'use strict';
    function r(r) {
        var e = r.length,
            n = r.indexOf('?'),
            t = r.indexOf('#');
        t = -1 == t ? e : t, n = -1 == n ? t : n;
        var a = r.substr(0, n),
            i = r.substr(n + 1, t - n - 1),
            s = r.substr(t + 1);
        return {
            host: a,
            query_str: i,
            hash: s
        };
    }
    function e(e, n) {
        var t = r(e),
            a = t.query_str,
            i = [];
        for (var s in n)
            n.hasOwnProperty(s) && i.push(s + '=' + encodeURIComponent(n[s]));
        return i.length > 0 && (a += ('' != a ? '&' : '') + i.join('&')), t.host + ('' != a ? '?' + a : '') + ('' != t.hash ? '#' + t.hash : '');
    }
    function n(r, e, n, t) {
        r = r || location.href;
        var a = r.indexOf('&'),
            i = r.length,
            s = r.replace(/^[\w\d]+:[\/\\]+/g, '').split('').reverse();
        Array.prototype.indexOf || (Array.prototype.indexOf = function(r, e) {
            var n;
            if (null == this)
                throw new TypeError('this is null or not defined');
            var t = Object(this),
                a = t.length >>> 0;
            if (0 === a)
                return -1;
            var i = +e || 0;
            if (1 / 0 === Math.abs(i) && (i = 0), i >= a)
                return -1;
            for (n = Math.max(i >= 0 ? i : a - Math.abs(i), 0); a > n;) {
                if (n in t && t[n] === r)
                    return n;
                n++;
            }
            return -1;
        });
        var o = i - 1 - s.indexOf('/');
        -1 != a && -1 == r.indexOf('?') && a > o && (r = r.replace('&', '?'));
        var u = new RegExp('([\\?&]' + e + '=)[^&#]*');
        if (!r.match(u)) {
            var h = r.indexOf('?');
            return -1 == h ? r + '?' + e + '=' + n : h == r.length - 1 ? r + e + '=' + n : r + '&' + e + '=' + n;
        }
        return t === !0 ? r.replace(u, '$1' + n) : r;
    }
    return {
        parseUrl: r,
        join: e,
        addParam: n
    };
}; 

var Class = classFunction();
var Url = urlFunction();
var isx5 = -1 != navigator.userAgent.indexOf('TBS/'),
__moon_report = window.__moon_report || function() {},
MOON_AJAX_SUCCESS_OFFSET = 3,
MOON_AJAX_NETWORK_OFFSET = 4,
MOON_AJAX_ERROR_OFFSET = 5,
MOON_AJAX_TIMEOUT_OFFSET = 6,
MOON_AJAX_COMPLETE_OFFSET = 7;

function joinUrl(e) {
    var t = {};
    return 'undefined' != typeof uin && (t.uin = uin), 'undefined' != typeof key && (t.key = key),
    'undefined' != typeof pass_ticket && (t.pass_ticket = pass_ticket), 'undefined' != typeof wxtoken && (t.wxtoken = wxtoken),
    'undefined' != typeof top.window.devicetype && (t.devicetype = top.window.devicetype),
    'undefined' != typeof top.window.clientversion && (t.clientversion = top.window.clientversion),
    t.x5 = isx5 ? '1' : '0', t.f = 'json', Url.join(e, t);
}

function Ajax(obj) {
    var type = (obj.type || 'GET').toUpperCase(),
        url = joinUrl(obj.url),
        mayAbort = !!obj.mayAbort,
        async = 'undefined' == typeof obj.async ? !0 : obj.async,
        xhr = new XMLHttpRequest,
        timer = null,
        data = null;
    if ('object' == typeof obj.data) {
        var d = obj.data;
        data = [];
        for (var k in d)
            d.hasOwnProperty(k) && data.push(k + '=' + encodeURIComponent(d[k]));
        data = data.join('&');
    } else
        data = 'string' == typeof obj.data ? obj.data : null;
    xhr.open(type, url, async);
    var _onreadystatechange = xhr.onreadystatechange;
    xhr.onreadystatechange = function() {
        if ('function' == typeof _onreadystatechange && _onreadystatechange.apply(xhr), 3 == xhr.readyState && obj.received && obj.received(xhr),
        4 == xhr.readyState) {
            xhr.onreadystatechange = null;
            var status = xhr.status;
            if (status >= 200 && 400 > status)
                try {
                    var responseText = xhr.responseText,
                        resp = responseText;
                    if ('json' == obj.dataType)
                        try {
                            resp = eval('(' + resp + ')');
                            var rtId = obj.rtId,
                                rtKey = obj.rtKey || 0,
                                rtDesc = obj.rtDesc,
                                checkRet = !0;
                            rtId && rtDesc && RespTypes && !RespTypes.check(resp, rtDesc) && reportRt(rtId, rtKey, RespTypes.getMsg() + '[detail]' + responseText + ';' + obj.url);
                        } catch (e) {
                            return void (obj.error && obj.error(xhr));
                        }
                    console.log(resp);
                    obj.success && obj.success(resp);
                } catch (e) {
                    throw __moon_report({
                        offset: MOON_AJAX_SUCCESS_OFFSET,
                        e: e
                    }), e;
                }
            else {
                try {
                    obj.error && obj.error(xhr);
                } catch (e) {
                    throw __moon_report({
                        offset: MOON_AJAX_ERROR_OFFSET,
                        e: e
                    }), e;
                }
                if (status || !mayAbort) {
                    var __ajaxtest = window.__ajaxtest || '0';
                    __moon_report({
                        offset: MOON_AJAX_NETWORK_OFFSET,
                        log: 'ajax_network_error[' + status + '][' + __ajaxtest + ']: ' + url + ';host:' + top.location.host,
                        e: ''
                    });
                }
            }
            clearTimeout(timer);
            try {
                obj.complete && obj.complete();
            } catch (e) {
                throw __moon_report({
                    offset: MOON_AJAX_COMPLETE_OFFSET,
                    e: e
                }), e;
            }
            obj.complete = null;
        }
    }, 'POST' == type && xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8'),
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest'), 'undefined' != typeof obj.timeout && (timer = setTimeout(function() {
        xhr.abort('timeout');
        try {
            obj.complete && obj.complete();
        } catch (e) {
            throw __moon_report({
                offset: MOON_AJAX_COMPLETE_OFFSET,
                e: e
            }), e;
        }
        obj.complete = null, __moon_report({
            offset: MOON_AJAX_TIMEOUT_OFFSET,
            log: 'ajax_timeout_error: ' + url,
            e: ''
        });
    }, obj.timeout));
    try {
        xhr.send(data);
    } catch (e) {
        obj.error && obj.error();
    }
    return xhr;
}

function aoejifowc(){
	var el_toolbar = document.getElementById('js_toobar3');
	var el_like = el_toolbar.querySelector('#like3'),
    	el_likeNum = el_toolbar.querySelector('#likeNum3'),
    	el_readNum = el_toolbar.querySelector('#readNum3');

	var tmpAttr = el_like.getAttribute('like'),
            tmpHtml = el_likeNum.innerHTML,
            isLike = parseInt(tmpAttr) ? parseInt(tmpAttr) : 0,
            // like = isLike ? 0 : 1,
            like = 1;
            likeNum = parseInt(tmpHtml) ? parseInt(tmpHtml) : 0;
    var param = {
            url: '/mp/appmsg_like?__biz=' + biz + '&mid=' + mid + '&idx=' + idx + '&like=' + like + '&f=json&appmsgid=' + appmsgid + '&itemidx=' + itemidx,
            data: {
                is_temp_url: window.is_temp_url || 0
            },
            type: 'POST',
            success: function(res) {
                var data = eval('(' + res + ')');
                0 == data.base_resp.ret && (isLike ? (Class.removeClass(el_like, 'praised'), el_like.setAttribute('like', 0),
                likeNum > 0 && '100000+' !== tmpHtml && (el_likeNum.innerHTML = likeNum - 1 == 0 ? 'Like' : likeNum - 1)) : (el_like.setAttribute('like', 1),
                Class.addClass(el_like, 'praised'), '100000+' !== tmpHtml && (el_likeNum.innerHTML = likeNum + 1)));
            },
            async: !0
        };

    // alert(JSON.stringify(param));
    Ajax(param);
    // alert('hahaha');
    return ljafownfio();
};

function ljafownfio(){
    var el_toolbar = document.getElementById('js_toobar3');
    var el_likeNum = el_toolbar.querySelector('#likeNum3'),
    el_readNum = el_toolbar.querySelector('#readNum3');
    var readNum = parseInt(el_readNum.innerHTML);
    var likeNum = parseInt(el_likeNum.innerHTML);
    var re = {"result": "eccute😄🌑😄🌑😄addlike","read_num":readNum, "like_num":likeNum};
    return JSON.stringify(re);
}

aoejifowc();





